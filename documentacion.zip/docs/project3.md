**Proyecto 3**

El Proyecto consiste en hacer una webapp de reconocimiento facial que sea capaz de encontrar personas perdidas por sus rasgos faciales suponiendo que se utilicen cámaras de seguridad para poder captar el rostro de la persona que se está buscando.

Esta aplicación tendrá las siguientes vistas

1.	Menú principal (Subir imagen y buscar a la persona)
2.	Resultados de la búsqueda

A la hora de subir la informacion de la persona perdida una cámara se activara en tiempo real buscara al individuo en cuestión. Cuando este sea encontrado se le redirecciona a la pagina de resultados donde se podra ver donde se vio la persona.

El componente de reconocimiento facial sera independiente. por lo que puede ser portable.

Las tecnologias que se tenia en mente para hacer este sistema eran Angular, ASP.NET y Python. Se decidio al final utilizar completamente Python para desarrollar la parte Web y el Backend.
