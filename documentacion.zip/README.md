# lost_and_found

Una aplicacion web de reconocimiento facial para encontrar personas perdidas

## Uso
para ejecutar esta webapp solo debe correr el archivo app.py y abrir localhost:5000 en un navegador

## Instalacion
Este proyecto tiene dependencias de python3 y es oficialmente compatible con Linux y Mac.
En Windows no es oficialmente compatible ya que la instalacion de dlib es inestable. 

Hay una guia de instalacion para los interesados:
https://github.com/ageitgey/face_recognition/issues/175#issue-257710508

Algunas de estas dependencias deben ser instaladas manualmente:
dlib==19.19.99

Creditos a https://github.com/ageitgey por la libreria face_recognition

Desarrollado por Lucy y Bryan